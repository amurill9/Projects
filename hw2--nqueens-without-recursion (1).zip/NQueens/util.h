#include <string>
#include <vector>

using namespace std;

using wordvec = vector<string>;

wordvec split (const string& line, const string& separator);
