cd RoboGrader
python3 robochecker.py Bard ~/workspace
cd ..
