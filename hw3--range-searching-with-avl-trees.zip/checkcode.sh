cd RoboGrader
python3 robochecker.py Wordrange ~/workspace
cd ..
